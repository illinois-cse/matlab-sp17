t_ana=[0:0.1:10];
N_ana=rad_analytic(t_ana,100,1);
plot(t_ana,N_ana)