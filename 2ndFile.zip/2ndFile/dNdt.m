function dN = dNdt(t, N, lambda)
lambda =1;
dN = -lambda*N;
end